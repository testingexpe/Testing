/**
 * Simbolo.java (VERSION0)
 *
 * Creado: 26 de julio de 2007, 22:54
 *
 */

package nametbl;

/**
 *
 * @author Rub�n Ortiz Alcocer
 */
public class Simbolo {
    
    private String simbolo;
    private String tipo_objeto;
    private String tipo_recurso;
    
    
    /** CONSTRUCTOR: simbolo */
    public Simbolo(String nombre) {
        simbolo = nombre;
        tipo_objeto = "NO_INFO";
        tipo_recurso = "R_NO_INFO";
    }
    
    public void setSimbolo(String simb) {
        simbolo = simb;
    }
    
    public void setTipoObjeto(String objeto) {
        tipo_objeto = objeto;
    }
    
    public void setTipoRecurso(String recurso) {
        tipo_recurso = recurso;
    }
    
    public String getSimbolo() {
        return simbolo;
    }
    
    public String getTipoObjeto() {
        return tipo_objeto;
    }
    
    public String getTipoRecurso() {
        return tipo_recurso;
    }
    
    public void pintarSimbolo() {
        System.out.println("Simbolo: " + simbolo + ", Tipo de objeto: " + tipo_objeto + ", Tipo de recurso: " + tipo_recurso);
    }
}
