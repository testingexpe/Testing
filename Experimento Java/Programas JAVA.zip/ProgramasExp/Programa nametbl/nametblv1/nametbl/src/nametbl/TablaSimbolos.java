/**
 * TablaSimbolos.java (VERSION1)
 *
 * Creado: 26 de julio de 2007, 23:10
 *
 */

package nametbl;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Rub�n Ortiz Alcocer
 */
public class TablaSimbolos {
    
    private ArrayList tabla;
    
    
    /** CONSTRUCTOR: TablaSimbolos */
    public TablaSimbolos() {
        tabla = new ArrayList();
    }
    
    public void insertarSimbolo(String lexema) {
        Simbolo simbolo = new Simbolo(lexema);
        if (this.esta(lexema) != -1)
        {
            System.out.println("ERROR: el simbolo " + lexema + " ya existe en la tabla.");
            return;
        }
        tabla.add(simbolo);
            
    }
    
    public void asignarObjeto(String lexema, String objeto) {
        Simbolo simbolo;
        int posicion = this.esta(lexema);
        
        if (posicion == -1)
        {
            System.out.println("ERROR: simbolo no encontrado");
            return;
        }

        simbolo = (Simbolo) tabla.get(posicion);
        if (objeto.compareTo("SISTEMA")!=0 &&
                objeto.compareTo("RECURSO")!=0 &&
                objeto.compareTo("COMBINADO")!=0)
        {
            System.out.println("ERROR: " + objeto + " no es un tipo de objeto permitido");
            return;
        }
        
        simbolo.setTipoObjeto(objeto);

    }
    
    public void asignarRecurso(String lexema, String recurso) {
        Simbolo simbolo;
        int posicion = this.esta(lexema);
        
        if (posicion == -1)
        {
            System.out.println("ERROR: simbolo no encontrado");
            return;
        }

        simbolo = (Simbolo) tabla.get(posicion);
        String objeto = simbolo.getTipoObjeto();
        if ((recurso.compareTo("R_SISTEMA")==0 && objeto.compareTo("SISTEMA")==0) ||
                recurso.compareTo("FUNCION")==0 || recurso.compareTo("DATO")==0)
        {
            simbolo.setTipoRecurso(recurso);
        }
        else
            System.out.println("ERROR: " + recurso + " no es un tipo de recurso permitido");
    }
    
    public void buscarSimbolo(String lexema) {
        Simbolo simbolo;
        int posicion = this.esta(lexema);
        
        if (posicion == -1)
        {
            System.out.println("ERROR: simbolo no encontrado");
            return;
        }
        simbolo = (Simbolo) tabla.get(posicion);
        simbolo.pintarSimbolo();        
    }
    
    public void imprimirTabla() {
        Iterator iterador = tabla.listIterator();
        Simbolo simbolo;
        int contador = 0;
        
        while (iterador.hasNext()) {
            simbolo = (Simbolo) iterador.next();
            System.out.print("[" + (contador++) + "] ");
            simbolo.pintarSimbolo();
        }
    }
    
    private int esta(String lexema) {
        Iterator iterador = tabla.listIterator();
        Simbolo simbolo;
        int contador = 0;
        
        while (iterador.hasNext()) {
            simbolo = (Simbolo) iterador.next();
            if (simbolo.getSimbolo().compareTo(lexema)==0)
                return contador;
            contador++;
        }
        return -1;
    }
}
