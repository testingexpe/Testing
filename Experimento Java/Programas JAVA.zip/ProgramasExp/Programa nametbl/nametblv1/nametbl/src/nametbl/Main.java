/**
 * Main.java (VERSION1)
 *
 * Creado: 26 de julio de 2007, 22:47
 *
 * nametbl: lee comandos de un fichero y los
 * procesa para probar una serie de funciones
 */

package nametbl;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;



/**
 *
 * @author Rub�n Ortiz Alcocer
 */
public class Main {
    
    public Main() {
    }
    
    public static void main(String[] args) throws FileNotFoundException {
        
        TablaSimbolos tabla_simbolos = new TablaSimbolos();
        
        /** s�lo un fichero puede ser procesado */
        if (args.length != 1) {
            System.out.println("ERROR: n�mero de par�metros a la entrada incorrecto.");
            System.out.println("USO: nametbl <fichero-de-entrada>");
            return;
        }
        
        File fichero = new File(args[0]);
        // tengo que mirar que el fichero se puede leer
        Scanner sc = new Scanner(fichero);
        
        // caracteres que pueden formar una palabra
        sc.useDelimiter("[^��������������a-zA-Z0-9_]");
        
        String comando;
        String simbol;
        String tipo;
        
        while (sc.hasNext()) {
            if ((comando = sc.next()).length() != 0)
            {
                if (comando.compareTo("imprimir_tabla")==0)
                {
                    tabla_simbolos.imprimirTabla();
                }
                else if (sc.hasNext() && (simbol = sc.next()).length()!=0)
                {
                    if (comando.compareTo("insertar_simbolo")==0)
                    {
                        tabla_simbolos.insertarSimbolo(simbol);
                    }
                    else if (comando.compareTo("buscar_simbolo")==0)
                    {
                        tabla_simbolos.buscarSimbolo(simbol);
                    }
                    else if (sc.hasNext() && (tipo = sc.next()).length()!=0)
                    {
                        if (comando.compareTo("asignar_objeto")==0)
                        {
                            tabla_simbolos.asignarObjeto(simbol, tipo);
                        }
                        else if (comando.compareTo("asignar_recurso")==0)
                        {
                            tabla_simbolos.asignarRecurso(simbol, tipo);
                        }
                    }
                }
            }
        }
    }
    
}
