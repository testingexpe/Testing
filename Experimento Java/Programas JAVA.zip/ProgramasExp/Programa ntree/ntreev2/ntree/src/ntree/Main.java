/**
 * Main.java (VERSION2)
 *
 * Creado: 24 de agosto del 2007, 23:49
 *
 * ntree: lee comandos de un fichero y los
 * procesa para probar una serie de funciones
 */
package ntree; 
 
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


/**
 *
 * @author Rub�n Ortiz Alcocer
 */

public class Main {

    public Main() {
    }

    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        
    	Arbol arbol = new Arbol();
        
        /** s�lo un fichero puede ser procesado */
        if (args.length != 1) { //0
            System.out.println("ERROR: numero de parametros a la entrada incorrecto.");
            System.out.println("USO: ntree <fichero-de-entrada>");
            return;
        }
        
        File fichero = new File(args[0]);
        Scanner scanner;
		try { //1
			scanner = new Scanner(fichero);
		} catch (FileNotFoundException e) { //2
			System.out.println ("ERROR: el fichero no puede ser abierto para lectura.");
			System.out.println ("USO: ntree <fichero-de-entrada>");
			return;
		}
        
        // caracteres que pueden formar una palabra
        scanner.useDelimiter("[^��������������a-zA-Z0-9_]");
        
        String comando;
        String parametro1;
        String parametro2;
        String parametro3;
        
        while (scanner.hasNext()) { //3
            if ((comando = scanner.next()).length() != 0) //4
            {
                if (comando.compareTo("imprimir")==0) //5
                {
                    arbol.imprimir();
                }
                else if (scanner.hasNext() && (parametro1 = scanner.next()).length()!=0) // 6
                {
                    if (comando.compareTo("buscar")==0) // 7
                    {
                        arbol.buscar(parametro1);
                    }
                    else if (scanner.hasNext() && (parametro2 = scanner.next()).length()!=0) // 8
                    {
                        if (comando.compareTo("raiz")==0) // 9
                        {
                            arbol.raiz(parametro1, parametro2);
                        }
                        else if (comando.compareTo("hermanos")==0) // 10
                        {
                            arbol.hermano(parametro1, parametro2);
                        }
                        else if (scanner.hasNext() && (parametro3 = scanner.next()).length()!=0) // 11
                        {
                        	if (comando.compareTo("hijo")==0) // 12
                        	{
                        		arbol.hijo(parametro1, parametro2, parametro3);
                        	}
                        }
                    }
                }
            }
        }
    }
}