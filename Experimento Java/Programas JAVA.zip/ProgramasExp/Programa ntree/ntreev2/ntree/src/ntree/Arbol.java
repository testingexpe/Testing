/**
 * 
 * arbol.java (VERSION2)
 * 
 * Creado: 25 de agosto del 2007, 0:20
 *
 */
package ntree;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * 
 * @author Ruben Ortiz Alcocer
 * 
 */

public class Arbol {
	
	private ArrayList<String> claves_padre;
	private ArrayList<String> claves;
	private ArrayList<String> contenidos;
	
	
	/** CONSTRUCTOR: arbol */
	public Arbol () {
		claves_padre = new ArrayList<String>();
		claves = new ArrayList<String>();
		contenidos = new ArrayList<String>();
	}

	
	/**
	 * METODO: raiz
	 * @param clave
	 * @param contenido
	 */
	public void raiz (String clave, String contenido) {
		
		claves_padre.add(0, "");
		claves.add(0, clave);
		contenidos.add(0, contenido);
	}
	
	
	/**
	 * METODO: hijo
	 * @param clave_padre
	 * @param clave
	 * @param contenido
	 */
	public void hijo (String clave_padre, String clave, String contenido) {
		
		int posicion = claves.indexOf(clave_padre); /** correci�n */
		
		if (posicion == -1) { // 13
			System.out.print("ERROR: no existe ningun padre con la clave especificada.");
			return;
		}
		
		claves_padre.add(posicion+1, clave_padre);
		claves.add(posicion+1, clave);
		contenidos.add(posicion+1, contenido);
	}
	
	
	/**
	 * METODO: buscar
	 * @param clave
	 */
	public void buscar (String clave) {
		
		int posicion = claves.indexOf(clave);
		
		if (posicion == -1) { // 14
 			System.out.println("ERROR: no existe ningun elemento con la clave especificada.");
			return;
		}
		
		System.out.println (contenidos.get(posicion));
	}
	
	
	/**
	 * METODO: hermano
	 * @param clave1
	 * @param clave2
	 */
	public void hermano (String clave1, String clave2) {
		
		int posicion1 = claves.indexOf(clave1);
		int posicion2 = claves.indexOf(clave2);
		
		if ((posicion1 == -1) || (posicion2 == -1)) { // 15
			System.out.println ("ERROR: no existe alguno de los elementos especificados.");
			return;
		}
		
		if (claves_padre.get(posicion1).compareTo(claves_padre.get(posicion2)) == 0) // 16
			System.out.println ("los elementos con clave " + clave1 + " y " + clave2 + " son hermanos.");
		else // 17 
			System.out.println ("los elementos con clave " + clave1 + " y " + clave2 + " no son hermanos.");
	}
	
	
	/**
	 * METODO: imprimir
	 */
	public void imprimir () {
		
		Iterator iterador_claves = claves.listIterator();
		Iterator iterador_contenidos = contenidos.listIterator();
		int profundidad;
		String elemento;
		
		while (iterador_claves.hasNext()) { // 18
			elemento = (String) iterador_claves.next();
			profundidad = buscarProfundidad(elemento);
			
			while (profundidad > 0) { // 19
				System.out.print("    ");
				profundidad--;
			}
			System.out.println ("Clave: " + elemento + ", Contenido: " + iterador_contenidos.next());
		}
		
	}
	
	
	/**
	 * buscarProfundidad
	 * @param clave
	 * @return int
	 */
	private int buscarProfundidad (String clave) {
		
		int contador = 0; /** correcion */
		String elemento;
		String elemento_anterior = claves_padre.get(0);
		String raiz = claves.get(0);
		boolean encontrado = false;
		Iterator iterador_padres = claves_padre.listIterator();
		Iterator iterador_claves = claves.listIterator();
		
		
		while (iterador_padres.hasNext() && !encontrado) { // 20
			elemento = (String) iterador_padres.next();
			
			if (raiz.compareTo(elemento) == 0) // 21
				contador = 1;
			else 
				if (elemento_anterior.compareTo(elemento) != 0) // 22
					contador++;
				
			if (clave.compareTo((String) iterador_claves.next()) == 0) // 23
				encontrado = true;
			
			elemento_anterior = elemento;
		}
		
		return contador;
	}
}
