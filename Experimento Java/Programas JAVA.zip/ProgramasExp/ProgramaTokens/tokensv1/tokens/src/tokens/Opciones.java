/*
 * Opciones.java (VERSION1)
 *
 * Creado: 19 de julio de 2007, 23:30
 *
 * Version1
 */

package tokens;

import java.util.ArrayList;

/**
 *
 * @autor Rub�n Ortiz Alcocer
 */
public class Opciones {
    
    private boolean alfabetico;
    private boolean minusculas;
    private int nMinimo;
    private ArrayList caracteres;
    
    /** CONSTRUCTOR: opciones [por defecto]*/
    public Opciones()
    {
        alfabetico = false;
        minusculas = false;
        nMinimo = 1;
        caracteres = new ArrayList();
        
        char caracter;
        for (caracter = 'a'; caracter <= 'z'; caracter++)
        {
            caracteres.add(caracter);
        }
        for (caracter = 'A'; caracter <= 'Z'; caracter++)
        {
            caracteres.add(caracter);
        }
        for (caracter = '0'; caracter <= '9'; caracter++)
        {
            caracteres.add(caracter);
        }
    }
    
    public boolean getAlfabetico ()
    {
        return alfabetico;
    }
    
    public void setAlfabetico ()
    {
        alfabetico = true;
        
        char caracter;
        
        for (caracter = '0'; caracter <= '9'; caracter++)
        {
            caracteres.remove(caracter);
        }
    }
    
    public boolean getMinusculas ()
    {
        return minusculas;
    }
    
    public void setMinusculas ()
    {
        minusculas = true;
        
        char caracter;
    
        for (caracter = 'A'; caracter <= 'Z'; caracter++)
        {
            caracteres.remove(caracter);
        }
    }
    
    public int getNMinimo ()
    {
        return nMinimo;
    }
    
    public void setNMinimo (int opcion)
    {
        nMinimo = opcion;
    }
    
    public void setCaracteres (char opcion)
    {
        caracteres.add(opcion);
    }
    
    public boolean esCaracterPosible (char caracter)
    {
        return caracteres.contains(caracter);
    }
}
