/*
 * Main.java (VERSION1)
 *
 * Creado: 19 de julio de 2007, 22:56
 *
 * Version1
 */

package tokens;

import java.io.IOException;

/**
 *
 * @autor Rub�n Ortiz Alcocer
 *
 */
public class Main {
    
    public Main() {
    }
    
    /**
     * @programa ppal para procesar la entrada
     */
    public static void main(String[] args)
    {
        // Numero de argumentos
        int num_args = args.length;
        
        // opciones por defecto
        Opciones opciones = new Opciones();
        
        int i = 0;
        while (i < num_args)
        {
            if (args[i].compareTo("-i")==0)
            {
                opciones.setMinusculas();
                i++;
            }
            else if (args[i].compareTo("-a")==0)
            {
                opciones.setAlfabetico();
                i++;
            }
            else if (args[i].compareTo("-c")==0 && (i <= num_args-2))
            {
                i++;
                while ((i <= num_args-1) && (args[i].compareTo("-a")!=0) && (args[i].compareTo("-i")!=0) && (args[i].compareTo("-m")!=0))
                {
                    if(args[i].length() == 1)
                    {
                        opciones.setCaracteres(args[i].charAt(0));
                    }
                    else
                    {
                        System.out.println ("ERROR: 'chars' deben ser caracteres.");
                        System.out.println ("USO: tokens [-ai] [-c chars] [-m cuenta]");
                        return;
                    }
                    i++;
                }
            }
            else if ((args[i].compareTo("-m")==0) && (i <= num_args-2))
            {
                i++;
                if (args[i] != null)
                {
                    try
                    {
                        opciones.setNMinimo(Integer.parseInt(args[i]));
                    }
                    catch (NumberFormatException nfe)
                    {
                        System.out.println ("ERROR: 'cuenta' debe ser numerico.");
                        System.out.println ("USO: tokens [-ai] [-c chars] [-m cuenta]");
                        return;
                    }
                }   
            }
            else
            {
                System.out.println ("USO: tokens [-ai] [-c chars] [-m cuenta]");
                return;   
            }
            
        }
        
        ListaTokens lista = new ListaTokens(opciones);
        try {
            lista.rellenarLista();
            lista.printarArbol();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
}
