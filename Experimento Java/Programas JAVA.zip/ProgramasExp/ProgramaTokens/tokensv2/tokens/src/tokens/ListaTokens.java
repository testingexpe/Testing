/*
 * ArbolTokens2.java (VERSION2)
 *
 * Creado: 20 de julio de 2007, 11:55
 *
 * Version2
 */

package tokens;

import java.io.IOException;

/**
 *
 * @autor Rub�n Ortiz Alcocer
 */
public class ListaTokens {
    
    private Nodo actual;
    private Opciones opciones;
    
    
    /** CONTRUCTOR: listatokens */
    public ListaTokens(Opciones ops)
    {
        actual = null;
        opciones = ops;
    }
 
    
    public void rellenarLista () throws IOException
    {
        char caracter;
        StringBuffer contenido = new StringBuffer();
        boolean descartar = false;
        
        while ( (caracter = (char)System.in.read()) != 65535) // hasta EOF (Ctrl + z)
        {
            
            if ((caracter != 13) && (caracter != 10) && (caracter != ' ')) // enter o espacio
            {
                if ((opciones.getAlfabetico()) && (caracter >= '0') && (caracter <= '9')) // error ||
                {
                    System.out.println ("ERROR: no se pueden procesar tokens alfanumericos.");
                    System.out.println ("USO: tokens [-ai] [-c chars] [-m cuenta]");
                    descartar = true;
                }

                if (opciones.esCaracterPosible(caracter) == false)
                {
                    System.out.println ("ERROR: caracter '" + caracter + "' no permitido.");
                    System.out.println ("USO: tokens [-ai] [-c chars] [-m cuenta]");
                    descartar = true;;
                }

                contenido.append(caracter);
            }
            else
            {
                if ((!descartar) && (caracter != 10) && (contenido.length() != 0))
                {
                    System.out.println ("insertar");// insetar solo los tokens correctos
                    insertar(contenido.toString());
                }
                descartar = false;
                contenido = new StringBuffer();
            }
        }
    }
    
    

    
    private void insertar (String contenido)
    {
        
        
        if (actual == null) // insercion del primer elemento
            actual = new Nodo (contenido);
        else
        {
            Nodo auxiliar = actual;
            Nodo anterior = null;
            
            //busqueda de la posici�n a insertar
            
            while ((auxiliar.siguiente != null) && (auxiliar.token.compareTo(contenido)<0))
            {
                anterior = auxiliar;
                auxiliar = auxiliar.siguiente;
                
            }
            
            if (auxiliar.token.compareTo(contenido) == 0)       
            {
                
                auxiliar.contador++;
            }
            else if (auxiliar.token.compareTo(contenido) > 0)
            {
                
                if (anterior == null)
                {
                    Nodo temporal = actual;
                    actual = new Nodo (contenido);
                    actual.siguiente = temporal;
                }
                else
                {
                    Nodo temporal = anterior.siguiente;
                    anterior.siguiente = new Nodo (contenido);
                    anterior.siguiente.siguiente = temporal;
                }
            }
            else
            {
                
                auxiliar.siguiente = new Nodo(contenido);
            }
        }

    }
    
    public void printarArbol ()
    {
        Nodo auxiliar = actual;
        while (auxiliar != null)
        {
            if (opciones.getNMinimo() <= auxiliar.contador)
            {
                System.out.println ("   " + auxiliar.token + "   " + auxiliar.contador);
            }
            auxiliar = auxiliar.siguiente;
        }
    }
         
    /** 
    * CLASE: nodo
    */
    private static class Nodo
    {
        String token;
        int contador;
        Nodo siguiente;
        
        /** CONSTRUCTOR: nodo */
        public Nodo (String cont)
        {
            token = cont;
            contador = 1;
            siguiente = null;
        }
    }
}
