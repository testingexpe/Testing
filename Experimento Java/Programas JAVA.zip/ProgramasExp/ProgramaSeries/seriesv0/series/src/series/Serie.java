/*
 * Serie.java
 *
 * Created on 10 de julio de 2007
 *
 * -- Clase: Serie (VERSION 0)
 */
package series;

import java.lang.Math;
/**
 *
 * @author Rub�n Ortiz Alcocer
 *
 */
public class Serie {
    
    public Serie()
    {
    }
    
     /**
     * m�todo para imprimir la serie por pantalla
     * (de comienzo a fin segun cadencia)
     */
    public void printarSerie (String comienzo, String fin, String cadencia) {

        boolean sonEnteros = true;
        
        // parametros.tipo = entero
        try {
            Integer.parseInt(comienzo);
            Integer.parseInt(fin);
            if (cadencia != null)
                Integer.parseInt(cadencia);
        }
        catch (NumberFormatException nfe)
        {
            sonEnteros = false;
        }
        
        // asignaci�n de rangos
        if (sonEnteros)
        {
            int _comienzo = Integer.valueOf(comienzo);
            int _fin = Integer.valueOf(fin);
            int _cadencia;
            if (cadencia != null) {
                _cadencia = Integer.valueOf(cadencia);
                if (_cadencia == 0) {
                    System.out.println ("ERROR: cadencia debe ser un n�mero diferente de 0");
                    return;
                }
            }
            else
                _cadencia = 1;
            
            int limite = Math.abs((_fin - _comienzo)/_cadencia)+1;
            for (int i=0; i < limite ; i++)
            {
                System.out.println(_comienzo);
                if (_comienzo <= _fin)
                    _comienzo = _comienzo + _cadencia;
                else
                    _comienzo = _comienzo - _cadencia;
            } // for
        }
        else
        {
            float _comienzo = Float.valueOf(comienzo);
            float _fin = Float.valueOf(fin);
            float _cadencia;
            if (cadencia != null)
            {
                _cadencia = Float.valueOf(cadencia);
                if (_cadencia == 0.0) {
                    System.out.println ("ERROR: cadencia debe ser un n�mero diferente de 0.0");
                    return;
                }
            }
            else
                _cadencia = 1.0f;
            
            float limite = Math.abs((_fin - _comienzo)/_cadencia)+1.0f;
            for (int i=0; i < limite; i++)
            {
                System.out.println(_comienzo);
                if (_comienzo <= _fin)
                    _comienzo = _comienzo + _cadencia;
                else
                    _comienzo = _comienzo - _cadencia;
            } // for
        }
        
    } //printarSerie
}
