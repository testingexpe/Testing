/*
 * Series.java
 *
 * Created on 12 de julio de 2007
 *
 * -- Codificaci�n del programa series: VERSI�N 1
 * -- Clase: Series
 */
package series;

import java.lang.Math;

/**
 *
 * @author Rub�n Ortiz Alcocer
 *
 */
public class Series {
    
    public Series()
    {
    }
    
     /**
     * m�todo para imprimir la serie por pantalla
     * (de comienzo a fin segun cadencia)
     */
    public void printarSerie (String comienzo, String fin, String cadencia) {

        boolean sonEnteros = true;
        
        // parametros.tipo = entero
        try {
            Integer.parseInt(comienzo);
            Integer.parseInt(fin);
            if (cadencia != null)
                Integer.parseInt(cadencia);
        }
        catch (NumberFormatException nfe)
        {
            sonEnteros = false;
        }
        
        // asignaci�n de rangos
        if (sonEnteros)
        {
            int valorComienzo = Integer.valueOf(comienzo);
            int valorFin = Integer.valueOf(fin);
            int valorCadencia;
            if (cadencia != null) {
                valorCadencia = Integer.valueOf(cadencia);
                if (valorCadencia == 0) {
                    System.out.println ("ERROR: cadencia debe ser un n�mero diferente de 0");
                    return;
                }
            }
            else
                valorCadencia = 1;
            
            int limite = Math.abs((valorFin - valorComienzo)/valorCadencia)+1;
            for (int i=0; i < limite ; i++)
            {
                System.out.println(valorComienzo);
                if (valorComienzo <= valorFin)
                    valorComienzo = valorComienzo + valorCadencia;
                else
                    valorComienzo = valorComienzo - valorCadencia;
            } // for
        }
        else
        {
            float valorComienzo = Float.valueOf(comienzo);
            float valorFin = Float.valueOf(fin);
            float valorCadencia;
            if (cadencia != null)
            {
                valorCadencia = Float.valueOf(cadencia);
                if (valorCadencia == 0.0) {
                    System.out.println ("ERROR: cadencia debe ser un n�mero diferente de 0.0");
                    return;
                }
            }
            else
                valorCadencia = 1.0f;
            
            float limite = Math.abs((valorFin - valorComienzo)/valorCadencia)+1;
            for (int i=0; i < limite; i++)
            {
                System.out.println(valorComienzo);
                System.out.println ("- " + i + " < " + limite);
                if (valorComienzo <= valorFin)
                    valorComienzo = valorComienzo + valorCadencia;
                else
                    valorComienzo = valorComienzo - valorCadencia;
            } // for
        }
        
    } //printarSerie
}
