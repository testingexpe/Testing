/**
 * Main.java
 *
 * Created on 12 de julio de 2007
 *
 * -- Codificaci�n del programa series: VERSI�N 1
 */
package series;

import series.Series;

/**
 *
 * @author: Rub�n Ortiz Alcocer
 *
 */

public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * programa ppal para procesar la entrada
     */
    public static void main(String[] argv)
    {        
        // Numero de argumentos
        int argc = argv.length;
        
        if ((argc < 2) || (argc > 3))
            System.out.println ("USO: series comienzo fin [cadencia]");
        else
        {
            // comprobamos que comienzo es un par�metro num�rico
            try { 
                Integer.parseInt(argv[0]);
            }
            catch (NumberFormatException nfe)
            {
                try {
                    Float.parseFloat(argv[0]);
                }
                catch (NumberFormatException nfe2)
                {
                    System.out.println ("ERROR: el parametro comienzo no es numerico");
                    System.out.println ("USO: series comienzo fin [cadencia]");
                    return;
                }
            }
            
            // comprobamos que fin es un par�metro num�rico
            try {
                Integer.parseInt(argv[1]);
            }
            catch (NumberFormatException nfe)
            {
                try
                {
                    Float.parseFloat(argv[1]);
                }
                catch (NumberFormatException nfe2)
                {
                    System.out.println ("ERROR: el parametro fin no es numerico");
                    System.out.println ("USO: series comienzo fin [cadencia]");
                    return;
                }
            }
            
            if (argc == 3) 
            {
                // comprobamos que la cadencia es un par�metro num�rico
                try {
                    Integer.parseInt(argv[2]);
                    
                }
                catch (NumberFormatException nfe)
                {
                    try {
                        Float.parseFloat(argv[2]);
                    }
                    catch (NumberFormatException nfe2)
                    {
                        System.out.println ("ERROR: el parametro cadencia no es numerico");
                        System.out.println ("USO: series comienzo fin [cadencia]");
                        return;
                    }
                }
            } 
            
            Series miserie = new Series();
            
            if (argc == 3)
                miserie.printarSerie(argv[0], argv[1], argv[2]);
            else
                miserie.printarSerie(argv[0], argv[1], null);
            
            
        }
    }
    
}
