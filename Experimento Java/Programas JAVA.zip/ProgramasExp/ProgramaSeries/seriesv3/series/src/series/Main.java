/**
 * Main.java
 *
 * Created on 12 de julio de 2007
 *
 * -- Codificaci�n del programa series: VERSI�N 3
 */
package series;

import series.Serie;

/**
 *
 * @author: Rub�n Ortiz Alcocer
 *
 */

public class Main {
    
    public Main() {
    }
    
    /** 
     *  Funcion que devuelve el valor num�rico de "argumento"
     *  si representa un numero 
     */
    private static double aNumero (String argumento) 
    {
        try
        {
            Double.parseDouble(argumento);  
        }
        catch (NumberFormatException nfe)
        {
            System.out.println ("ERROR: el parametro "+ argumento +" no es numerico");
            System.out.println ("USO: series comienzo fin [cadencia]");
            System.exit(-1);
        }
        return Double.valueOf(argumento);
    }
    
    /**
     * programa ppal para procesar la entrada
     */
    public static void main(String[] argv)
    {        
        // Numero de argumentos
        int argc = argv.length;
        
        double comienzo;
        double fin;
        double cadencia = 1.0f;
        
        if ((argc < 2) || (argc > 3))
            System.out.println ("USO: series comienzo fin [cadencia]");
        else
        {
            // comprobamos que comienzo es un par�metro num�rico
            comienzo = aNumero (argv[0]);
            
            // comprobamos que fin es un par�metro num�rico
            fin = aNumero (argv[1]);
            
            if (argc == 3) 
            {
                // comprobamos que la cadencia es un par�metro num�rico
                cadencia = aNumero (argv[2]);
            } 
            
            Serie miserie = new Serie();
            
            miserie.printarSerie(comienzo, fin, cadencia); 
            
        }
    }
    
}
