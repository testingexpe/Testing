/*
 * Serie.java
 *
 * Created on 12 de julio de 2007
 *
 * -- Codificaci�n del programa series: VERSI�N 3
 * -- Clase: Serie
 */
package series;

import java.lang.Math;

/**
 *
 * @author Rub�n Ortiz Alcocer
 *
 */
public class Serie {
    
    public Serie()
    {
    }
    
     /**
     * m�todo para imprimir la serie por pantalla
     * (de comienzo a fin segun cadencia)
     */
    public void printarSerie (double comienzo, double fin, double cadencia) {

        boolean sonEnteros = false;
        
        if (cadencia == 0.0) {
            System.out.println ("ERROR: cadencia debe ser un n�mero diferente de 0");
            return;
        }
        
        // parametros.tipo == entero
        if ((comienzo == (int)comienzo) && (fin == (int)fin) && (cadencia == (int)cadencia))
            sonEnteros = true;
        
        int limite = (int) Math.abs((fin - comienzo)/cadencia)+1;
        for (int i=0; i < limite ; i++)
        {
            if (sonEnteros)
                System.out.println((int)comienzo);
            else
                System.out.println((float)comienzo);
            
            if (comienzo <= fin)
                comienzo = comienzo + cadencia;
            else
                comienzo = comienzo - cadencia;
        } // for
    } //printarSerie
}
