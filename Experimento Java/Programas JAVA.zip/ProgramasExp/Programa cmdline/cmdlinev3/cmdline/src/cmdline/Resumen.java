/**
 * Resumen.java (VERSION3)
 *
 * Creado: 21 de septiembre del 2007, 17:52
 *
 * cmdline: analiza sintactica y semanticamente una l�nea de comandos.
 * 
 */
package cmdline;

import java.util.ArrayList;
import java.util.Iterator;
 
/**
 *
 * @author Ruben Ortiz Alcocer
 */

public class Resumen {

	private boolean hay_medida;
	private boolean demasiada_medida;
	private ArrayList<String> medida;
	private ArrayList<String> opcion_busqueda;
	private boolean hay_valor;
	private double valor;
	private ArrayList<String> ficheros;
	
	public Resumen () {
		hay_medida = false;
                demasiada_medida = false;
		medida = new ArrayList<String>();
		opcion_busqueda = new ArrayList<String>();
		hay_valor = false;
		valor = 0;
		ficheros = new ArrayList<String>();
	}

	public void setHayMedida() {
		if (hay_medida)
			demasiada_medida = true;
		hay_medida = true;
	}

	public void setMedida(String valor_medida) {
		if (valor_medida.length() == 2)
			valor_medida = valor_medida.concat("HE");
		if (valor_medida.length() == 3)
			valor_medida = valor_medida.concat("M");
		medida.add(valor_medida);
	}

	public void setOpcionBusqueda(String opcion) {
		opcion_busqueda.add(opcion);
	}

	public void setValor(String numero) {
		try
                {
                    hay_valor = true;
                    Double.parseDouble(numero);
                    this.valor = Double.valueOf(numero);
                }
                catch (NumberFormatException nfe)
                {
                    System.out.println ("ERROR: valor debe ser un n�mero real.");
                    System.exit(-1);
                }
	}

	public void setFicheros(String fichero) {
		ficheros.add(fichero);
	}

	public void imprimir() {
		
		
		// ERRORES
		if (!hay_medida)
			System.err.println ("No se ha proporcionado opcion de medida");
		else if (ficheros.size() == 0)
			System.err.println ("No se han proporcionado ficheros de entrada");
		else if (demasiada_medida)
			System.err.println ("Demasiadas opciones de medida.");
		else if (medida.size()==0)
			System.err.println ("No hay opcion de medida");
		else if (medida.indexOf("erroneo")!=-1)
			System.err.println ("Medida no valida.");
		else if (opcion_busqueda.size() > 1)
			System.err.println ("Demasiadas opciones de busqueda");
		else if (((opcion_busqueda.indexOf("inferior") != -1) ||
				  (opcion_busqueda.indexOf("superior") != -1)) &&
				 (!hay_valor))
			System.err.println ("No se ha proporcionado un valor");
		else {
			
			// RESUMEN
			System.out.print ("RESUMEN: ");
			System.out.println (medida.get(0));
			if (opcion_busqueda.size() > 0)
				System.out.println ("         " + opcion_busqueda.get(0));
			if (hay_valor)
				System.out.println ("         " + valor);
			
			Iterator iterador = ficheros.listIterator();
			System.out.println ("ficheros:");
			while (iterador.hasNext())
				System.out.println ("          " + iterador.next());
		}
	}
}

