/**
 * Main.java (VERSION1)
 *
 * Creado: 21 de septiembre del 2007, 17:51
 *
 * cmdline: analiza sintactica y semanticamente una l�nea de comandos.
 *
 */
package cmdline;

/**
 *
 * @author Ruben Ortiz Alcocer
 */
public class Main {
    
    public Main() {
    }
    
    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        int numero_argumentos = args.length;
        int i = 0;
        boolean es_opcion = true;
        
        Resumen resumen = new Resumen();
        
        // recorremos todas las opciones de la linea
        while ((i < numero_argumentos)  && es_opcion) {
            if ((args[i].compareTo("-medida")==0) || (args[i].compareTo("-me")) == 0) {
                resumen.setHayMedida();
                i++;
                
                if ((args[i].compareTo("GKO")==0) ||
                        (args[i].compareTo("GKOM")==0) ||
                        (args[i].compareTo("LKO")==0) ||
                        (args[i].compareTo("LKOM")==0) ||
                        (args[i].compareTo("GKH")==0) ||
                        (args[i].compareTo("GKHM")==0) ||
                        (args[i].compareTo("LKH")==0) ||
                        (args[i].compareTo("LKHM")==0) ||
                        (args[i].compareTo("GI")==0) ||
                        (args[i].compareTo("GIHE")==0) ||
                        (args[i].compareTo("LI")==0) ||
                        (args[i].compareTo("LIHE")==0)) {
                    resumen.setMedida(args[i]);
                } else
                    resumen.setMedida("erroneo");
                i++;
            } else if ((args[i].compareTo("-t")==0) ||
                    (args[i].compareTo("-todas")) == 0) {
                resumen.setOpcionBusqueda("todas");
                i++;
            } else if ((args[i].compareTo("-ma")==0) ||
                    (args[i].compareTo("-maximo")) == 0) {
                resumen.setOpcionBusqueda("maximo");
                i++;
            } else if ((args[i].compareTo("-mi")==0) ||
                    (args[i].compareTo("-minimo")) == 0) {
                resumen.setOpcionBusqueda("minimo");
                i++;
            } else if ((args[i].compareTo("-pr")==0) ||
                    (args[i].compareTo("-promedio")) == 0) {
                resumen.setOpcionBusqueda("promedio");
                i++;
            } else if ((args[i].compareTo("-in")==0) ||
                    (args[i].compareTo("-inferior")) == 0) {
                resumen.setOpcionBusqueda("inferior");
                if (++i < numero_argumentos)
                    resumen.setValor(args[i]);
                i++;
            } else if ((args[i].compareTo("-su")==0) ||
                    (args[i].compareTo("-superior")) == 0) {
                resumen.setOpcionBusqueda("superior");
                if (++i < numero_argumentos)
                    resumen.setValor(args[i]);
                i++;
            } else
                es_opcion = false;
        }
        
        // recorremos todos los ficheros de la linea
        while (i < numero_argumentos) {
            resumen.setFicheros(args[i++]);
        }
        
        resumen.imprimir();
    }
}
