/*
 * Fichero.java (Count VERSION0)
 *
 * Created on 18 de abril de 2007, 20:09
 *
 */

package count;

import java.io.FileInputStream;

/**
 * @author Rub�n Ortiz Alcocer
 */
public class Fichero {
    
    FileInputStream Fichero = null;
    String Nombre = null;
    
    /** CONSTRUCTOR: fichero */
    public Fichero(String nombre) {
        if(nombre != null)
            try
            {
                Fichero = new FileInputStream(nombre);
                Nombre = nombre;
                System.setIn(Fichero);
            }
            catch(java.io.FileNotFoundException ex)
            {
                if (nombre != null)
                    System.err.println("ERROR: El fichero " + Nombre + " no puede ser leido.");
            } 
    }
    
    
    public int[] Procesar() {
        
        int[] lpc = new int[3];
        lpc[0] = 0;
        lpc[1] = 0;
        lpc[2] = 0;
        int lineas = 0;
        int palabras = 0;
        int caracteres = 0;
        
        try {
            int caracter;
            while ( (caracter = System.in.read()) != -1 )
            {
                if ((caracter == 32) || (caracter == 9)) { 
                    palabras ++;
                }
                if (caracter == 10) {
                    lineas ++;
                }
                if ((caracter != 13) || (caracter != 10)) { 
                    caracteres ++;
                }
            }
        }
        catch(java.io.IOException e) {
        }
        if (Nombre != null)
            System.out.println (" " + lineas + "   " + palabras + "   " + caracteres + "   " + Nombre);
        else
            System.out.println (" " + lineas + "   " + palabras + "   " + caracteres);
        lpc[0] = lineas;
        lpc[1] = palabras;
        lpc[2] = caracteres;
        return lpc;
    }
}
