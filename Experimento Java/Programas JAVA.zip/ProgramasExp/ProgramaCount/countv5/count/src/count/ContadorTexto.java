/*
 * ContadorTexto.java (Count VERSION5)
 *
 * Created on 18 de abril de 2007, 20:09
 *
 */

package count;

import java.io.FileInputStream;

/**
 * @author Rub�n Ortiz Alcocer
 */
public class ContadorTexto {
    
    private FileInputStream Fichero = null;
    private String Nombre = null;
    
    /** CONSTRUCTOR: fichero */
    public ContadorTexto(String nombre) {
        if(nombre != null)
            try
            {
                Fichero = new FileInputStream(nombre);
                Nombre = nombre;
                System.setIn(Fichero);
            }
            catch(java.io.FileNotFoundException ex)
            {
                if (nombre != null)
                {
                    System.err.println("ERROR: El fichero " + nombre + " no puede ser leido.");
                    System.err.println("USO: count [fichero, fichero...]");
                }
            }
        else
            Nombre = ""; //entrada estandar
    }
    
    
    public void procesar(ElementosTexto elementos) {
        
        int lineas = 0;
        int palabras = 0;
        int caracteres = 0;
        
        boolean contenido = false;
        
        
        if (Fichero == null && Nombre == null)
            return;
        
        
        try {
            int caracter;
            while ( (caracter = System.in.read()) != -1 ) // Ctrl + z (EOF)
            {
                // espacio o tabulador
                if ((caracter == 32) || (caracter == 9)) {
                    palabras ++;
                }
                
                // salto de linea o EOF
                if (caracter == 10) { 
                    lineas ++;
                    if (contenido)
                    {
                        palabras ++;
                        contenido = false;
                    }
                }
                
                // salto de linea
                if ((caracter != 13) && (caracter != 10)) { 
                    caracteres ++;
                    contenido = true;
                }
            }
            
            if (contenido)
            {
                palabras ++;
                lineas ++;
            }
        }
        catch(java.io.IOException e) {
            System.err.println("ERROR: El fichero " + Nombre + " no puede ser leido.");
            System.err.println("USO: count [fichero, fichero...]");
        }
        
        if (Nombre != null)
            System.out.println (" " + lineas + "   " + palabras + "   " + caracteres + "   " + Nombre);
        
        if (elementos != null) {
            elementos.setNumeroLineas(lineas);
            elementos.setNumeroPalabras(palabras);
            elementos.setNumeroCaracteres(caracteres);
        }
    }
}
