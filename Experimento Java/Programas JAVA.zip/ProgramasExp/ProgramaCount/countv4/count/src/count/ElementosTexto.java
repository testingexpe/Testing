/*
 * ElementosTexto.java (Count VERSION4)
 *
 * Created on 10 de julio de 2007, 10:57
 *
 */

package count;

/**
 * @author Rub�n Ortiz Alcocer
 */
public class ElementosTexto {

    private int numeroLineas;
    private int numeroPalabras;
    private int numeroCaracteres;
    
    /** CONSTRUCTOR: ContadorTecto */
    public ElementosTexto() {
        numeroLineas = 0;
        numeroPalabras = 0;
        numeroCaracteres = 0;
    }
    
    public int getNumeroLineas () {
        return numeroLineas;
    }
    
    public int getNumeroPalabras () {
        return numeroPalabras;
    }
    
    public int getNumeroCaracteres () {
        return numeroCaracteres;
    }
    
    public void setNumeroLineas (int lineas) {
        numeroLineas = lineas;
    }
    
    public void setNumeroPalabras (int palabras) {
        numeroPalabras = palabras;
    }
        
    public void setNumeroCaracteres (int caracteres) {
        numeroCaracteres = caracteres;
    }
}
