/*
 * Main.java (Count VERSION4)
 *
 * Created on 18 de abril de 2007, 18:58
 *
 */

package count;

/**
 * @author Rub�n Ortiz Alcocer
 */
public class Main {
    
    public Main() {
    }
    
    public static void main(String[] argv) {
        
        int argc = argv.length;
        
        ElementosTexto elementos = new ElementosTexto();
        int lineasTotales = 0;
        int palabrasTotales = 0;
        int caracteresTotales = 0;
        
        ContadorTexto fich = null;
        for (int i=0; i<argc; i++) {
            fich = new ContadorTexto(argv[i]);
                
            fich.procesar(elementos);
            lineasTotales =  lineasTotales + elementos.getNumeroLineas();
            palabrasTotales =  palabrasTotales + elementos.getNumeroPalabras();
            caracteresTotales = caracteresTotales + elementos.getNumeroCaracteres();
        }
        
        if (argc == 0) {
            // si no hay fichero se procesa la entrada estandar
            fich = new ContadorTexto(null);
            fich.procesar(null);
        }
        else if (argc > 1)
            System.out.println (" " + lineasTotales + "   " + palabrasTotales + "   " + caracteresTotales + "   Total");
    }
}
