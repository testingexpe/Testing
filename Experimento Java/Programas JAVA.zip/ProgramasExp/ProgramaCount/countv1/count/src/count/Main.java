/*
 * Main.java (Count VERSION1)
 *
 * Created on 18 de abril de 2007, 18:58
 *
 */

package count;

/**
 * @author Rub�n Ortiz Alcocer
 */
public class Main {
    
    public Main() {
    }
    
    public static void main(String[] argv) {
        // TODO code application logic here
        
        int argc = argv.length;
        
        int[] lpcT = new int[3];
        int lineasT = 0;
        int palabrasT = 0;
        int caracteresT = 0;
        
        Fichero fich = null;
        for (int i=0; i<argc; i++) {
            fich = new Fichero(argv[i]);
            if (fich != null) {
                lpcT = fich.Procesar();
            }
            lineasT =  lineasT + lpcT[0];
            palabrasT =  palabrasT + lpcT[1];
            caracteresT = caracteresT + lpcT[2];
        }
                
        if (argc == 0) {
            fich = new Fichero(null);
            lpcT = fich.Procesar();
        }
        else // if (argc > 1)
            System.out.println (" " + lineasT + "   " + palabrasT + "   " + caracteresT + "   Total");
    }
    
}
